from django.contrib import messages
from django.http import Http404, HttpResponseRedirect
from django.shortcuts import render, get_object_or_404, redirect, HttpResponse
from myapp.models import Post, Profile, Comment
from myapp.forms import CommentForm, SignUpForm, EmailPostForm, ProfileEditForm, UserEditForm, SearchForm
from django.core.paginator import Paginator, PageNotAnInteger, EmptyPage
from django.contrib.auth.decorators import login_required
from django.core.mail import send_mail
from django.db.models import Q, Count
from taggit.models import Tag


def signup_view(request):
    if request.method == 'POST':
        form = SignUpForm(request.POST)
        if form.is_valid():
            new_user = form.save()
            Profile.objects.create(user=new_user)
            messages.success(request, 'You account successfully register..!')
            return redirect('login')
    else:
        form = SignUpForm()
    return render(request, 'registration/register.html', dict(form=form))


def blog_index(request, tag_slug=None):
    posts = Post.objects.all()


    tag = None
    if tag_slug:
        post_list = posts.filter(tags__in=[tag])

    paginator = Paginator(posts, 3)
    page_number = request.GET.get('page')
    try:
        posts = paginator.page(page_number)
    except PageNotAnInteger:
        posts = paginator.page(1)
    except EmptyPage:
        posts = paginator.page(paginator.num_pages)

    return render(request, 'index.html', dict(posts=posts, tag=tag))


@login_required
def blog_detail(request, year, month, day, post):
    try:
        post = get_object_or_404(Post,
                                 slug=post,
                                 status='published',
                                 publish__year=year,
                                 publish__month=month,
                                 publish__day=day,
                                 )
        comments = post.comments.filter(active=True)
    except post.DoesNotExist:
        raise Http404('Data does not exist')
    new_comment = None
    if request.method == 'POST':
        comment_form = CommentForm(data=request.POST)
        if comment_form.is_valid():
            new_comment = comment_form.save(commit=False)
            new_comment.post = post
            new_comment.save()
            return redirect("/")
    else:
        comment_form = CommentForm()
    return render(request, 'details.html',
                  dict(posts=post, new_comment=new_comment, comment_form=comment_form, comments=comments))



@login_required
def post_share(request, id):
    post = get_object_or_404(Post, id=id, status='published')
    sent = False
    if request.method == 'POST':
        form = EmailPostForm(request.POST)
        if form.is_valid():
            cd = form.cleaned_data
            post_url = request.build_absolute_uri(post.get_absolute_url())
            subject = '{}({}) recommends you to read "{}"'.format(cd['name'], cd['email'], post.title)
            message = 'Read Post At: \n {}\n\n{}\' Comments:\n{}'.format(post_url, cd['name'], cd['comments'])
            send_mail(subject, message, 'pravindhole0777@gmail.com', [cd['to']])
            sent = True
        messages.success(request, 'Your post will shared..')
        return redirect('blog_index')

    else:
        form = EmailPostForm()
    return render(request, 'post_share.html', {'post': post, 'form': form, 'sent': sent})


@login_required
def edit_user_profile(request):
    if request.method == 'POST':
        user_form = UserEditForm(instance=request.user, data=request.POST)
        profile_form = ProfileEditForm(instance=request.user,
                                       data=request.POST,
                                       files=request.FILES)
        if user_form.is_valid() and profile_form.is_valid():
            user_form.save()
            profile_form.save()
            messages.success(request, 'Profile	updated	successfully')
            return redirect('/')
        else:
            messages.error(request, 'Error Uploading your Profile')
    else:
        user_form = UserEditForm(instance=request.user)
        profile_form = ProfileEditForm(instance=request.user.profile)
    context =dict(user_form=user_form, profile_form=profile_form)
    return render(request, 'registration/edit_user_profile.html', context)


def serch_post(request):
    if request.method == 'GET':
        query = request.GET.get('q')
        submitbtn = request.GET.get('submit')
        if query is not None:
            results = Post.objects.filter(Q(title__icontains=query) | Q(body__icontains=query)).distinct()
            context = {'results': results, 'submitbtn': submitbtn}
            return render(request, 'serach.html', context)
        else:
            return render(request, 'index.html')
    else:
        return render(request, 'index.html')


def tagged(request, slug):
    tag = get_object_or_404(Tag, slug=slug)
    # Filter posts by tag name
    posts = Post.objects.filter(tags=tag)
    context = {
        'tag': tag,
        'posts': posts,
    }
    return render(request, 'index.html', context)


