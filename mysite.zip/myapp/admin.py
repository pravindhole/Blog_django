from django.contrib import admin

from myapp.models import Post, Comment,Profile

class PostAdmin(admin.ModelAdmin):
    list_display = ['title', 'slug', 'author', 'body', 'publish', 'created_on', 'updated_on','image', 'status']
    list_filter = ('status',)
    search_fields = ['title', 'body', 'author']
    row_id_fields = ('author',)
    date_hierarchy = 'publish'
    ordering = ['status', 'publish']
    prepopulated_fields = {'slug': ('title',)}


class CommentAdmin(admin.ModelAdmin):
    list_display = ['name', 'email', 'body', 'created', 'updated', 'active']
    list_filter = ('created', 'active', 'updated')
    search_fields = ['name', 'email', 'body']

@admin.register(Profile)
class ProfileAdmin(admin.ModelAdmin):
    list_display = ['user','date_of_birth','photo']

admin.site.register(Post, PostAdmin)
admin.site.register(Comment, CommentAdmin)
